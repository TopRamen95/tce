import React from 'react'

const Company = () => {
  return (
    <div>
      company page
    </div>
  )
}

export default Company
